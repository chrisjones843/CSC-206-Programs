/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 2/26/2019
 * Program Name: 7.11
 * Purpose: Give themean and standard deviation of ten numbers
 */
package program.pkg7.pkg11;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class Program711 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declare Variables
        Scanner input = new Scanner (System.in);
        double answer [];
        answer = new double [10];
        double sum = 0 ;
        int length = 10;
        double sd; 
     
        //Prompt user for ten intgers
        System.out.println(" Enter ten numbers :  ");
        answer [0] = input.nextDouble();
        answer [1] = input.nextDouble();
        answer [2] = input.nextDouble();
        answer [3] = input.nextDouble();
        answer [4] = input.nextDouble();
        answer [5] = input.nextDouble();
        answer [6] = input.nextDouble();
        answer [7] = input.nextDouble();
        answer [8] = input.nextDouble();
        answer [9] = input.nextDouble();
       System.out.println("Calculating....");
       
       
       //Declare MEAN method
       double mean = mean ( sum, length, answer );
       //Priint MEAN when vaule is returned
       System.out.println(" ");
       System.out.println(" ");
       System.out.println("The mean is " + mean %2d);
       
       //Declare STANDARD DEVIATION method
       double standard = standard ( mean ,answer, sum );
       System.out.printf("The Standard Deviation is %.2f " , standard);
    }
        // Mean Method 
        public static double mean (double sum, int length, double answer[] ) {
        
        double sum1 = answer [0] + answer [1] +  answer [2] + answer [3] + answer [4] + answer [5] + answer [6] + answer [7] + answer [8] + answer [9];
        double mean = sum1 / 10.0;
        
        return mean;
        }
        //STANDARD DEVIATION method
        public static double standard (double mean, double answer[], double sum ){
        
        double sum2 = answer [0] + answer [1] +  answer [2] + answer [3] + answer [4] + answer [5] + answer [6] + answer [7] + answer [8] + answer [9];
        double mean2 = sum2 / 10.0;
        double s1 = Math.pow(answer [0] - mean2, 2);
        double s2 = Math.pow(answer [1] - mean2, 2);
        double s3 = Math.pow(answer [2] - mean2, 2);
        double s4 = Math.pow(answer [3] - mean2, 2);
        double s5 = Math.pow(answer [4] - mean2, 2);
        double s6 = Math.pow(answer [5] - mean2, 2);
        double s7 = Math.pow(answer [6] - mean2, 2);
        double s8 = Math.pow(answer [7] - mean2, 2);
        double s9 = Math.pow(answer [8] - mean2, 2);
        double s10 = Math.pow(answer [9] - mean2, 2);
        double preStandard = s1 + s2 + s3 + s4 + s5 + s6 + s7 + s8 + s9 + s10;
        double preStandard1 = (preStandard / 10);
        double Standard = Math.sqrt(preStandard1);
     // Return Standard to the main method to be printed 
        return Standard;
        }
        //
        
    }
    

