/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 1/18/2019
 * Program Name: 2.6 MOD
 * Purpose: Finding the sum of digits from numbers between 0-99999
 */
package pkg2.pkg6.mod;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class MOD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         // Create a Scanner
        Scanner input = new Scanner(System.in);
        // Prompt User for Number
        System.out.print("Enter a number between 0 - 99999 ");
        int answer =input.nextInt();
        int num1 = answer;
        int num2 = answer;
        int num3 = answer;
        int num4 = answer;
        int num5 = answer;
        int print = num1 + num2 + num3 + num4 + num5;
        
        // Calculate
      print =  num1 % 10   + (num2 / 10) % 10 + (num3 / 100) %10 + (num4 / 1000) % 10 + (num5 / 10000) % 10;
        //Print
       System.out.println("The sum of digits is " +  print + "" );
    }
    
}
