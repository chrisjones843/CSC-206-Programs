/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program.pkg9.pkg1;

/**
 *
 * @author chrisjones843
 */
public class StopWatch {
    private String startTime;
    private String endTime;
    

public StopWatch (String startTime, String endTime) {
this.startTime = startTime;
this.endTime = endTime;
}

}