/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package program.pkg9.pkg1;

import java.util.Random;

/**
 *
 * @author chrisjones843
 */
public class Program91 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Random numbers = new Random(1);
        System.out.print("Numbers; ");
        for (double i = 0; i < 100000; i++)
            System.out.println(numbers.nextInt(100000) + " ");
        
    }
    
}
