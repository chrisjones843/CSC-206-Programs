/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 1/28/2019
 * Program Name: Program 3.22 
 * Purpose: Finding the distance of cooridnates from the center of a circlee
 */
package geometry;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class Geometry {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Make a scanner 
        Scanner input = new Scanner(System.in); 
        // Prompt user for x1 x2 y1 y2
        System.out.println("Please enter First Coordinate x SPACE y :");
        int X1 = input.nextInt();
        int Y1 = input.nextInt();
        //Prompt User for second coordinate
        System.out.print("Please enter Second Coordinate x SPACE y :");
        int X2 = input.nextInt();
        int Y2 = input.nextInt();
        //Calculate
       int display = (int) Math.sqrt((X2*X2)-(X1*X1) + (Y2*Y2)-(Y1*Y1));
        //Display
        if (display <= 10) 
        System.out.println( display + " , It is in the circle ");
        else
        System.out.print( display + " , Not in the circle'");
    }
    
}
