/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 2/6/2019
 * Program Name: 8.2
 * Purpose: Print 10X10 and find the mean as well as the largest number and smalest
 */
package program.pkg8.pkg2;

/**
 *
 * @author chrisjones843
 */
public class Program82 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declare variables
        int[][] matrix = { 
       {1,2,3,4,5,6,7,8,9,10},
            {11,12,13,14,15,16,17,18,19,20},
            {21,22,23,24,25,26,27,28,29,30},
            {31,32,33,34,35,36,37,38,39,40},
            {41,42,43,44,45,46,47,48,49,50},
            {51,52,53,54,55,56,57,58,59,60},
            {61,62,63,64,65,66,67,68,69,70},
            {71,72,73,74,75,76,77,78,79,80},
            {81,82,83,84,85,86,87,88,89,90},
            {91,92,93,94,95,96,97,98,99,100}
        };
        double mean = mean(matrix);
        // Loop for random numbers 0-100
        for (int row = 0; row < matrix.length; row++) {
            for (int column = 0; column < matrix[row].length; column++) {
                matrix[row][column] = (int) (Math.random() * 100);

        // Display
        System.out.print(matrix[row][column] + " ");
        }
        System.out.println();
        }
        System.out.println(mean);
        }
        
        // Mean Method 
      public static double mean ( int[][]matrix) {
            
        // Declare mean
     
        double mean = 0;
        for (int column = 0; column < matrix[0].length; column++) {
            int total = 0;
            for (int row = 0; row < matrix[9].length; row++) {
                total += matrix[row][column];
            }
          
            mean = (total / 100);
          
        
                }
           

        
        return mean;
    }
}
       
      
     
