/* Name: Christopher Jones
 * Date: 4/14/2019
 * Professor: J. Osborne
 * Program: 12.1
 * Purpose: Print the number of characters in the text file along with the number of lines
 */
package program12.pkg1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author chrisjones843
 */
public class Program121 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String fileName = "SCREWTAPELETTERS.txt";
        File inFile;
        Scanner fileScanner;
        String fileLine = null;
        inFile = new File (fileName);
        try {
           
          fileScanner = new Scanner (inFile);
          do {
          fileLine = fileScanner.nextLine();
         
          } while (fileScanner.hasNext());
          fileScanner.close();
        } catch (FileNotFoundException ex) {
            //Logger.getLogger(CharCountFile.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("file aint there cheif");
        }
           
            System.out.println("There are " + inFile.length() + " characters in this file");
    }
}
        
