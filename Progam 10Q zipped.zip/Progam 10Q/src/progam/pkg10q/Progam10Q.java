/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 3/31/2019
 * Program Name: 4.21 Mod
 * Purpose: Prompt user for SSN and Validate the users SSN 
 */
package progam.pkg10q;

/**
 *
 * @author chrisjones843
 */
public class Progam10Q {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Print Statements to test class
    myQueue queue = new myQueue();
        System.out.println("isEmpty() returns: " + queue.isEmpty());
        System.out.println("getSize() returns: " + queue.getSize());

}
}

