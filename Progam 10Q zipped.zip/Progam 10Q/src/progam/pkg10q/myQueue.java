/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package progam.pkg10q;

/**
 *
 * @author chrisjones843
 */
public class myQueue {
   private int[] item;
   private int size;


public myQueue() {
}

public void enqueue(int vaule){
    int value = 0;
    if (size >= item.length) {
        int[] temp = new int[item.length * 2];
        for (int i = 0; i < item.length; i++) {
            temp[i] = item[i];
        }
            item = temp;
    }
            item[size] = value;
            size++;
        
}
public int dequeue() {
    int value = item[size - 1];
    size--;
    return value;

}
public int peek() {
return item[size - 1];
}
public boolean isEmpty() {
    return (size == 0);
}
public int getSize() {
    return size;
}
} 