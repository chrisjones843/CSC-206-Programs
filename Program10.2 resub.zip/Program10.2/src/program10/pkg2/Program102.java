/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 3/26/2019
 * Program Name: 10.2
 * Purpose: Display Molecular masses of given formula
 */
package program10.pkg2;

/**
 *
 * @author chrisjones843
 */
public class Program102 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Elements sodium = new Elements();
        sodium.setName("Sodium");
        sodium.setSymbol("Na");
        sodium.setAtomicNumber(11);
        sodium.setAtomicWeight((int) 22.99);
        //Oxygen element
        Elements oxygen = new Elements();
        oxygen.setName("Oxygen");
        oxygen.setSymbol("O");
        oxygen.setAtomicNumber(8);
        oxygen.setAtomicWeight((int) 15.99);
        //Nitrogen Element
        Elements nitrogen = new Elements();
        nitrogen.setName("Nitrogen");
        nitrogen.setSymbol("N");
        nitrogen.setAtomicNumber(7);
        nitrogen.setAtomicWeight((int) 14.0067);
        //carbon element
        Elements carbon = new Elements();
        carbon.setName("Carbon");
        carbon.setSymbol("C");
        carbon.setAtomicNumber(6);
        carbon.setAtomicWeight((int) 12.0107);
        //hydrogen element
         Elements hydrogen = new Elements("Hydrogen","H",1,1.008);
         //
        double Glucose = 12 *hydrogen.getAtomicWeight()+ 6 * carbon.getAtomicWeight()  +  6*oxygen.getAtomicWeight();
        double Epinephrine =( carbon.getAtomicWeight() * 9) + ( hydrogen.getAtomicWeight() * 13 )+ ( nitrogen.getAtomicWeight() )+ ( oxygen.getAtomicWeight() * 3);
        double AceticAcid =( carbon.getAtomicWeight() ) + ( hydrogen.getAtomicWeight() *3) + ( carbon.getAtomicWeight() ) + ( oxygen.getAtomicWeight() ) + ( oxygen.getAtomicWeight() ) + ( hydrogen.getAtomicWeight() ) ;
       double SodiumBicarbonate =( sodium.getAtomicWeight()) + ( hydrogen.getAtomicWeight() ) + ( carbon.getAtomicWeight() ) + ( oxygen.getAtomicWeight() *3);
       System.out.println("Glucose's molecular mass is " + Glucose);
       System.out.println("EpiPen's molecular mass is " + Epinephrine);
       System.out.println("AceticAcid's molecular mass is " + AceticAcid);
       System.out.println("Baking Soda's molecular mass is " + SodiumBicarbonate);
       
                        
    }
    
}
