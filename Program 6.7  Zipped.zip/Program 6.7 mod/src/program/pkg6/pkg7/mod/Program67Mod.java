/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 2/6/2019
 * Program Name: 6.7
 * Purpose: Give the future investment vaule based up  invest amount and interest rate
 */
package program.pkg6.pkg7.mod;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class Program67Mod {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declare Variables and Scanner
        Scanner input = new Scanner(System.in);
        // Prompt User For Amount Invested
        System.out.println("Enter The Amount Invested : ");
        double amount = input.nextDouble();
        // Prompt User for Annual Interest Rate
        System.out.println("Enter the Annual Interest Rate : ");
        double rate = input.nextDouble();
        //Menu display 
        System.out.println(" Years        Future Vaule ");
        //Declare Method

        //LOOP to diplay years 1-30
        for (int years = 1; years < 31; years++) {
            //Declare Method
            double future = future(amount, rate, years);
            //Display years and future vaule for 1-30years
            System.out.println("  " + years + "               " + future);
        }

    }
    // Return the vaule of future invest

    public static double future(double amount, double rate, int years) {
        //new varibles to help calc the future vaule
        double amount1;
        double amount2;
        //Formula for calc of Future Vaule
        rate = (rate / 100);
        amount1 = amount + (amount * rate);
        //Loop the prints the future vaule 1-30 times
        for (amount2 = amount1; amount2 < amount1; amount2++);

        return amount2;
       

            
        }
}


        
        
    
    

