/* Author; Christopher Jones
 * Professor: J. Osborne
 * Section :  9:50 class , Intermediate
 * Date : 2/11/2019
 */
package exam1;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class Exam1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declare Variables 
        Scanner input = new Scanner(System.in);
        
       
        //prompt user for number
        System.out.println("Enter Numbers : ");
        int number;
        int max;
        int count;
        number = input.nextInt();
        max = number;
        while (number != 0) {
            number = input.nextInt();
            if (number > max) {
                max = number;
            }
            System.out.println(" the largest number is " + max + "The Occurrence of the largest number is " + number);
            //
        
        
        
    }
    }
}

    

