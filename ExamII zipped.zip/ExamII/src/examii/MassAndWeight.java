/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package examii;

/**
 *
 * @author chrisjones843
 */
public class MassAndWeight {
    private double massInKg;
    final double KG_TO_LBS = 2.204623 ;
    final double LBS_TO_OZ = 16;

    MassAndWeight(){
    }

MassAndWeight(double massInKg){
    this.massInKg = 0;
}
public double getMass() {
    return massInKg;
}
public void setMass(double massinGrams) {
    this.massInKg = massInKg;
}
public double getMassinGrams() {
    return massInKg ;
}
public double getMassInLbs() {
    return massInKg * KG_TO_LBS ;
}
public double getMassInOz() {
    return massInKg * KG_TO_LBS  * LBS_TO_OZ;
}
}