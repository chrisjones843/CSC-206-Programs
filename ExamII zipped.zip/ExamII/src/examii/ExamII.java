/* Name: Christopher Jones
 * Date: 4/5/2019
 * Professor: J. Osborne
 * Program: EXAM II
 * Purpose: Test the MassAndWeight class assigned to us
 */
package examii;

/**
 *
 * @author chrisjones843
 */
public class ExamII {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Testing MassAndWeight Class
        MassAndWeight hi = new MassAndWeight();
        
        hi.setMass(0.0283);
        System.out.println( hi.getMassinGrams() + " grams is 0.0283 kilgrams" );
        hi.setMass(1.000);
        System.out.println( hi.getMassInOz() + " grams is 1.0000 ounces " );
        hi.setMass(2.2046);
        System.out.println( hi.getMassInLbs() + " grams is 2.2046 pounds" );
        
    }
    
}
