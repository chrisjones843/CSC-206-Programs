/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 2/1/2019
 * Program Name: 4.21 Mod
 * Purpose: Prompt user for SSN and Validate the users SSN 
 */
package pkg4.pkg21.mod;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class MOD {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declare Variables
        String areaNumber = "000";
        String groupCode = "00";
        String lastFour = "0000";

        Scanner input = new Scanner(System.in);

        //Prompt User Social Number
        System.out.print(" Please Enter SSN In xxx-xx-xxxx Format :");
        String answer = input.nextLine();

        int length = answer.length();
        String area;
        String group;
        String last;
        area = answer.substring(0, 3);
        group = answer.substring(4, 6);
        last = answer.substring(7, 11);
        char check1 = answer.charAt(0);
        char check2 = answer.charAt(1);
        char check3 = answer.charAt(2);
        char check4 = answer.charAt(3);
        char check5 = answer.charAt(4);
        char check6 = answer.charAt(5);
        char check7 = answer.charAt(6);
        char check8 = answer.charAt(7);
        char check9 = answer.charAt(8);

        int a = area.length();
        int g = group.length();
        int l = last.length();

        // CHECK SPECIFICS
        if ("666".equals(area)) {
            System.out.println("You need Jesus , please repent and try again");
        }
        if ("078-05-1120".equals(answer)) {
            System.out.println(" Invalid SSN, please try again");
        }
        if ("219-09-9999".equals(answer)) {
            System.out.println("Invalid SSN, please try again");
        }
        if ("0000".equals(last)) {
            System.out.println(" last four dgits must be 0001-9999");
        }
        if ("00".equals(group)) {
            System.out.println(" group code must be 01-99");
        }
        if (check1 == '9') {
            System.out.println("area code cannot begin with 900-999");
        }

        // CHECK LETTERSS
        if (check1 >= 'A' && check1 <= 'Z') {
            System.out.println(" INVAILD, NUMBERS ONLY");
        } else if (check1 >= 'a' && check1 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check2 >= 'A' && check2 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check2 >= 'a' && check2 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check3 >= 'A' && check3 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check3 >= 'a' && check3 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check4 >= 'A' && check4 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check4 >= 'a' && check4 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check5 >= 'A' && check5 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check5 >= 'a' && check5 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check6 >= 'A' && check6 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check6 >= 'a' && check6 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check7 >= 'A' && check7 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check7 >= 'a' && check7 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check8 >= 'A' && check8 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check8 >= 'a' && check8 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check9 >= 'A' && check9 <= 'Z') {
            System.out.println("INVALID, NUMBERS ONLY");
        } else if (check9 >= 'a' && check9 <= 'z') {
            System.out.println("INVALID, NUMBERS ONLY");
        }
        //DISPLAY
        System.out.println(" Social Security is " + answer + "");
        
            
        }

     
    }
    

