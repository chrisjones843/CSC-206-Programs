/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 2/6/2019
 * Program Name: 5.51 Mod
 * Purpose: Convert decimal into Binary , Octal , or Hex Number
 */
package program.pkg5.pkg51;

import java.util.Scanner;

/**
 *
 * @author chrisjones843
 */
public class Program551 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Declare variables
        int decimal;
        int hexVaule;
        int octVaule = 0;
        int binVaule = 0 ;
        char hexDigit;
        char binDigit;
        char octDigit;
        String hexString = " ";
        String binString = " ";
        String octString = " ";

       
        
    
        Scanner input = new Scanner(System.in);
        // Prompt the user to enter a c
        System.out.print("Please enter the base to convert to (B)inary, (O)ctal, or (H)ex; ");
        char answer = input.next().charAt(0);
        // If the user acts dumb
        if (answer != answer){
        System.out.println(" Bro what are you doing enter h, b , or o");
        }
        //prompt user for decimal;
        if (answer == 'B') {
            System.out.print("Enter a decimal number: ");
        } else if (answer == 'b') {
            System.out.print("Enter a decimal number: ");
        } else  if (answer == 'O') {
            System.out.print("Enter a decimal number: ");
        } else if (answer == 'o') {
            System.out.print("Enter a decimal number: ");
        } else if(answer == 'H') {
            System.out.print("Enter a decimal number: ");
        } else if (answer == 'h') {
            System.out.print("Enter a decimal number: ");
        }
        decimal = input.nextInt();
        //IF THE USER IS BEING MAD STOOPID
        if (answer != decimal) {
        System.out.println("Quit playing around fam... enter B, H ,or O ");
        }

        // if user selects binary
        if (answer == 'b'||answer == 'B'){
            binVaule = decimal;
        // convert decimal to binary using remainder divsion
        while (decimal != 0) {
            binVaule = decimal % 2;
            binDigit = (char) (binVaule + '0');
            binString = binDigit + binString;
            decimal = decimal / 2;
        
        }
         //print binary 
        System.out.println("The Bin is " + binString);
        }
       
        
      
        // if user selects hex
         if (answer == 'h'|| answer == 'H') {
            hexVaule = decimal;
         // Converts decimal to Hex
        while (decimal != 0) {
            hexVaule = decimal % 16;
            if (hexVaule <= 9 && hexVaule >= 0) 
                hexDigit = (char) (hexVaule + '0');
             else 
                hexDigit = (char) (hexVaule - 10 + 'A');
           
            hexString = hexDigit + hexString;
            decimal = decimal / 16;
        }
         //Output the hex string
        System.out.println("The Hex number is " + hexString);
        }
        //If user selects Oct
         if (answer == 'O'|| answer =='o') {
            hexVaule = decimal; 
         // Converts decimal to oct
        while (decimal != 0) {
            octVaule = decimal % 8;
            octDigit = (char) (octVaule + '0');
            octString =  octDigit + octString;
            decimal = decimal / 8;
        }
         //Output the hex string
        System.out.println("The Oct number is " + octString);
        }
        
    }
         
        }
    

 


    