/*Christopher Jones 
 * 1/14/2019
 * HelloWorld
 * Program purpose: Printing hello world
 */
package helloworld;

/**
 *
 * @author View-Lab
 */
public class HelloWorld {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       for (int i = 0; i < 10; i++){ 
       System.out.println("Hello, world!");
        }

    }
}
