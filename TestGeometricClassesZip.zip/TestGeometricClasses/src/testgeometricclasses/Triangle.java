/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 3/26/2019
 * Program Name: 11.1
 * Purpose: A triangle class that creates a square and gives the perimeter 
 */
package testgeometricclasses;

/**
 *
 * @author josborne
 */
class Triangle extends GeometricObject {
 public int height;
 public int base;
 public int base2;
 
    //write the code
    Triangle () {
}
    Triangle (int height, int base, int base2 ) {
        this.base = base;
        this.base2 = base2;
        this.height = height;
    }
    public double getBase(){
        return base;
    }
public void setBase(int base) {
    this.base = base;
}
  public double getHeight(){
        return height;
}
public void setHeight(int height) {
    this.height = height;
}
 /** Return area */
  @Override
  public double getArea() {
    //write the code
     return (base + height) / 2;
  }

  /** Return perimeter */
  @Override
  public double getPerimeter() {
    //write the code
    return (base * height);
  }
  
    @Override
    public String toString() {
        return "[Triangle] Height & Base = " + height + ", " + base + ", " + base2;
    }
}
