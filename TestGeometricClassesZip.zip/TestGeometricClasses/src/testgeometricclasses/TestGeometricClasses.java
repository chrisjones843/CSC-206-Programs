/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 3/26/2019
 * Program Name: 11.1
 * Purpose: A Square/trianlge/Rectangle/Circle class that creates a square and gives the perimeter 
 */
package testgeometricclasses;

/**
 *
 * @author josborne
 */
public class TestGeometricClasses {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Circle circle = new Circle(4);
        System.out.println("A circle " + circle.toString());
        System.out.println("The color is " + circle.getColor());
        System.out.println("The radius is " + circle.getRadius());
        System.out.println("The area is " + circle.getArea());
        System.out.println("The diameter is " + circle.getDiameter());

        Rectangle rectangle = new Rectangle(2, 4);
        System.out.println("\nA rectangle " + rectangle.toString());
        System.out.println("The area is " + rectangle.getArea());
        System.out.println("The perimeter is " + rectangle.getPerimeter());


        Square square = new Square(4);
        System.out.println("\nA square " + square.toString());
        System.out.println("The area is " + square.getArea());
        System.out.println("The perimeter is " + square.getPerimeter());


        Triangle triangle = new Triangle(3, 4, 5);
        System.out.println("\nA triangle " + triangle.toString());
        System.out.println("The area is " + triangle.getArea());
        System.out.println("The perimeter is " + triangle.getPerimeter());

    }
}
