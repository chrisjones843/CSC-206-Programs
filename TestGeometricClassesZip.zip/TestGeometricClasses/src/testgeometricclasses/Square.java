/* Author: Christopher Jones 
 * Professor: J. Osborne
 * Date: 3/26/2019
 * Program Name: 11.1
 * Purpose: A square class that creates a square and gives the perimeter 
 */
package testgeometricclasses;

/**
 *
 * @author josborne
 */
public class Square extends GeometricObject {
  private double side;

  public Square() {
  }

  public Square(double side) {
    //write the code
    this.side = side;
  }

  /** Return width */
  public double getSide() {
    //write the code
    return side;
  }

  /** Set a new width */
  public void setSide(double side) {
    //write the code
    this.side = side;
  }

  /** Return area */
  @Override
  public double getArea() {
    //write the code
    return Math.pow(side, 2);
  }

  /** Return perimeter */
  @Override
  public double getPerimeter() {
    //write the code
    return side * 4;
  }
  
    @Override
    public String toString() {
        return "[Square] side = " + side;

    }
}


